# TODO

- [ ] Search NYT books by 'name' in Google Book API
- [ ] Add some animation
- [ ] Change Google Books API key when reach daily limit
- [ ] Redesign lightbox
- [ ] Include retailers prices and links (Amazon, Barnes & Noble, Books a Million ...)